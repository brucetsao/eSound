DFRobot-utility
=================
provide some useful function for Arduino

Install instructions:

* Download file
* decompress
* copy inside folder to your Arduino library folder
* restart your Arduino IDE

Copyright (C) DFRobot - www.dfrobot.com